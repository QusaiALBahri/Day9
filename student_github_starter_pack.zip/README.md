# Student Grade System

Short description: Simple Python app to calculate student GPAs.

## Requirements
- Python 3.11+
- Create a virtual environment

## Setup
```bash
python -m venv .venv
# activate venv (Windows)
.venv\Scripts\activate
pip install -r requirements.txt
```

## Run
```bash
python main.py
```

## Env (Secrets)
Create `.env` from `.env.example` and fill required keys.

## License
MIT © 2025 Qusai Omar AlBahri
